/**
 * The FullTimeStaffHire class is a subclass of the class StaffHire. 
 * This class represents that the staff member is hired on a full-time working base.
 * This class has 2 attributes. As a subclass it inherits all the attributes from the superclass and
 * adds two more to its class - the salary and the weekly hours.
 *
 * @author Stela Kostadinova
 * @student ID: 22042714
 */
public class FullTimeStaffHire extends StaffHire
{
    // instance variables
    private double salary;                
    private int weeklyFractionalHours; // The weekly hours for a full time position.

    /**
     * Constructor for objects of class FullTimeStaffHire.
     * This constructor adds 2 more parameters to the object.
     */
    public FullTimeStaffHire(int vacancyNumber, String designation, String jobType, String staffName, String joiningDate, String qualification, String appointedBy,
    boolean joined, double salary, int weeklyFractionalHours)
    {
        // initialise instance variables
        super (vacancyNumber,designation,jobType,staffName,joiningDate,qualification,appointedBy,
            joined);
        this.salary = salary;
        this.weeklyFractionalHours = weeklyFractionalHours; 
    }

    /**
     * Here we enter the salary, if the person has joined.
     * And the value of the salary is changing.
     * @param joined,newSalary The salary to be entered.  
     */
    public void setSalary(boolean joined, double newSalary)
    {
        if (joined == true) {
            salary = newSalary;
        } else {
            System.out.println("There is no staff appointed to set the salary");
        }
    }

    /**
     * @return The salary.
     */
    public double getSalary() 
    {
        return salary;
    }

    /**
     * I added extra code to this method.
     * Here we enter the weekly hours and assigning them to the weeklyFractionalHours if they are more than 30.
     * If they are less than or equal to 30 but more than zero, a suitable message will be printed to the terminal.
     * If the hours are equal to 0, an error message will be printed to the terminal.
     * @param weeklyHours  to be entered.
     */
    public void setWeeklyHours(int weeklyHours)
    {
        if (weeklyHours > 0 && weeklyHours <= 29)
        {
            System.out.println("The minimum working hours for this position is 30!"); 
        } else if (weeklyHours > 30 && weeklyHours <= 40) {
            weeklyFractionalHours = weeklyHours;
        } else {
            System.out.println("Error!Need to add hours or more hours added!");
        }
    }

    /**
     * @return The weekly hours.
     */
    public int getWeeklyHours()
    {
        return weeklyFractionalHours;
    }

    /**
     * Print all the details that has been entered to the text terminal in the order presented.
     * If the salary is more than zero the text will be displayed, otherwise you need to add the salary.
     */
    public void display()
    {   
        super.display();
        if (salary > 0){
            System.out.println("Salary: " + salary + " £");
            System.out.println("Hours per week: " + weeklyFractionalHours);
        }else {  
            System.out.println("The salary need to be added!");
        }
    }
}
