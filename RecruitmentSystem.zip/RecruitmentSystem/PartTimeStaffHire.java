/**
 * The PartTimeStaffHire class is a subclass of the class StaffHire. 
 * This class represents that the staff member is hired on a part-time working base.
 * This class has 4 attributes. As a subclass it inherits all the attributes from the superclass and
 * adds four more to its class - the workingHour, the wagesPerHour, shifts and terminated.
 *
 * @author Stela Kostadinova
 * @student ID: 22042714
 */
public class PartTimeStaffHire extends StaffHire
{
    // instance variables 
    private int workingHours;        // hours per day    
    private double wagesPerHour;    // how much you get paid per hour    
    private String shift;          // the shifts can be morning, day, evening or night   
    private boolean terminated;  // this indicates if the person is still working for the company or not 
    private int daysPerWeek; // how many days per week (extra code)

    /**
     * Constructor for objects of class PartTimeStaffHire,
     * This constructor adds 4 more parameters to the object.
     */
    public PartTimeStaffHire(int vacancyNumber, String designation, String jobType, String staffName, String joiningDate, String qualification,
    String appointedBy,boolean joined,int hoursPerDay,double wagesPerHour, String shift, int daysPerWeek)
    {
        // initialise instance variables
        super (vacancyNumber,designation,jobType,staffName,joiningDate,qualification,appointedBy,
            joined);
        this.workingHours = hoursPerDay;
        this.wagesPerHour = wagesPerHour;
        this.shift = shift;
        terminated = false;
        this.daysPerWeek = daysPerWeek;
    }

    /**
     * Here we enter the working hours, which are the hours per day.
     * Extra code.
     * @param hoursPerDay The hours to be entered.
     */
    public void setWorkingHours(int hoursPerDay)
    {
        if (hoursPerDay > 0 && hoursPerDay <= 10)
        {
            workingHours = hoursPerDay;
        } else if (hoursPerDay > 10) {
            System.out.println("The maximum hours per day is 10!");
        } else {
            System.out.println("Error!Need to add hours!");
        }
    }

    /**
     * @return The working hours.
     */
    public int getWorkingHours()
    {
        return workingHours;
    }

    /**
     * In this method we enter the wages per hour.
     * @param newWagesPerHour The payment to be entered.
     */
    public void setWagesPerHour(double newWagesPerHour)
    {
        wagesPerHour = newWagesPerHour;
    }

    /**
     * @return The wages per hour.
     */
    public double getWagesPerHour()
    {
        return wagesPerHour;
    }

    /**
     * Here we are setting the shifts. If the staff has joined, we are entering the shift: morning, day, evening or night.
     * If the staff hasn`t joined yet, a suitable message will be printed to the terminal. 
     * And if the new shift is during the night time, a suitable message will be printed.
     * @param newShift, joined The new shift to be entered.
     */
    public void setChangeShift(boolean joined, String newShift)
    {
        if (joined == true) {
            /*if (newShift == "night") //this is extra code that I added. I used nested if statements.
            {
                System.out.println("The applicant must be 18 or over!");
            } else if (newShift == "morning" || newShift == "day" || newShift == "evening")
            {
                shift = newShift;
            }else{
                System.out.println("Error");
            }*/
            shift = newShift;
        }else{
            System.out.println("This person hasn`t joined yet");
        }
    }

    /**
     * @return The shift.
     */
    public String getChangeShift()
    {
        return shift;
    }

    /**
     * This is extra code that I added.
     * Here we enter how many days per week the person is going to work. 
     * @param daysPerWeek The number of days to be entered.
     */
    public void setDaysPerWeek(int newDaysPerWeek) 
    {
        daysPerWeek = newDaysPerWeek;
    }

    /**
     * @return The number of days per week.
     */
    public int getDaysPerWeek() 
    {
        return daysPerWeek;
    }

    /**
     * In this method we can terminate the contract.
     * By default @terminated is false, which means the person is working in the company.
     * If we change it to true, all the information will be erased and the joined status will be changed to false.
     * @param terminated Changing the status to true.
     */
    public void isTerminate(boolean terminated)
    {   
        if (terminated == false) {
            System.out.println("This person is still working here.");
        } else {
            super.setStaffName(" ");
            super.setJoiningDate(" ");
            super.setQualification(" ");
            super.setAppointedBy(" ");
            super.setJoined(false);
            this.terminated = true;
        }
    }

    /**
     * Print all the details that has been entered to the text terminal in the order presented.
     * If the working hours are more than zero the text will be displayed, otherwise the working hours need to be added.
     * Here I added an extra code. The method is calculating the extra payment for an over time. 
     * If the person works from 7 to 10 hours a day there will be an increase of 20% between the hours 7 - 10(excluding 10).
     * If the person works 10 hours a day, there will be an increase of 50% for the last 1 hour.
     * This method also calculates the total income per day, week and year.
     */
    public void display()
    {   
        double overTime= 0;
        if (workingHours > 0){
            if (workingHours >= 7 && workingHours < 10) {
                overTime = wagesPerHour * 0.2;
            } 
            else if (workingHours == 10) {
                overTime = wagesPerHour * 0.5;
            } 
            super.display();
            System.out.println("Working hours per day: " + workingHours);
            System.out.println("Pay per hour: " + wagesPerHour);
            System.out.println("Shift: " + shift);
            System.out.println("Terminated: " + terminated);
            System.out.println("Days per week: " + daysPerWeek); // extra code
            System.out.println("The total income per day is:  " + ((workingHours * wagesPerHour) + overTime) + " £");
            System.out.println("The total income per week is:  " + ((workingHours * wagesPerHour) + overTime) * daysPerWeek + " £"); //extra code
            System.out.println("The total income per year is:  " + ((workingHours * wagesPerHour) + overTime) * daysPerWeek * 52 + " £"); // extra code
        } else {
            super.display();
        }
    }
}
