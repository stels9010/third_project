import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;

/**
 * The RecruitmentSystem class is build upon the functionality of the StaffHire program and provides a graphical user interface (GUI) 
 * for managing vacancy and staff information. This GUI allows users to input and view data related to vacancies and hired staff, 
 * which are stored in a list within the system. The class itself contains all the attributes from the StaffHire class and its sub-classes,
 * one main method and twenty-three new methods related to the program.
 * 
 * @author Stela Kostadinova
 * @student ID: 22042714 
 * @date 04.05.2023
 */

public class RecruitmentSystem implements ActionListener
{
    /**The private ArrayList 'staff' is used to store instances of the StaffHire class.
     *This allows for easy management and manipulation of the objects within the program. 
     *The 'frame' object is a JFrame instance that represents the main window of the program's graphical user interface.
     */
    private ArrayList<StaffHire> staff = new ArrayList<StaffHire>();
    private JFrame frame;

    //instance variables
    private JLabel vacancyNumberLabel;
    private JLabel designationLabel;
    private JLabel jobTypeLabel;
    private JLabel staffNameLabel;
    private JLabel joiningDateLabel;
    private JLabel qualificationLabel;
    private JLabel appointedByLabel;
    private JLabel salaryLabel;
    private JLabel weeklyFractionalHoursLabel;
    private JLabel workingHoursLabel;
    private JLabel wagesPerHourLabel;
    private JLabel shiftLabel;
    private JLabel terminatedLabel;
    private JLabel daysPerWeekLabel;
    private JLabel displayNumberLabel;
    private JLabel addFullTimeLabel;
    private JLabel addPartTimeLabel;
    private JLabel addSalaryLabel;
    private JLabel addShiftLabel;
    private JLabel clearLabel;

    private JTextField vacancyNumberTextF;
    private JTextField designationTextF;
    private JTextField jobTypeTextF;
    private JTextField staffNameTextF;
    private JTextField joiningDateTextF;
    private JTextField qualificationTextF;
    private JTextField appointedByTextF;
    private JTextField salaryTextF;
    private JTextField weeklyFractionalHoursTextF;
    private JTextField workingHoursTextF;
    private JTextField wagesPerHourTextF;
    private JTextField shiftTextF;
    private JTextField daysPerWeekTextF;
    private JTextField displayNumberTextF;

    private JCheckBox joinedCheckBox;

    private JButton addFullTimeButton;
    private JButton addPartTimeButton;
    private JButton terminateButton;
    private JButton setSalaryButton;
    private JButton setWorkingShiftButton;
    private JButton displayNumberButton;
    private JButton clearButton;

    /**
     * The GUI is created in the constructor. This constructor contains JFrame, contentPane, JLabel, JTextField,
     * JButton, JCheckBox. Different methods such as - setting the Font name, weight, size and color of the label; setBorder 
     * method for creating a line border with color around the Text-field; method for aligning the component in the center; 
     * method for creating an invisible spacing between the components; method for setting the focus of the component to false; 
     * an action listener method that is called when a specific action is performed on the component. Many of the methods in 
     * the constructor are repetitive, including the one used to create the staffNameLabel component, which serves as an example.
     */  
    public RecruitmentSystem()
    {
        //This line of code creates a new instance of the JFrame class and sets its title to "Recruitment System".
        frame = new JFrame("Recruitment System");
        // The parameter JFrame.EXIT_ON_CLOSE ensures that the program is properly terminated when the user clicks the window`s close button.
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // The contentPane is a containter object that holds all the components of the program
        Container contentPane = frame.getContentPane(); 
        contentPane.setLayout(new FlowLayout());
        //setting a GridLayout with 18 rows and 2 collumns, with horizontal gap of 15 and vertical gap of 10
        contentPane.setLayout(new GridLayout(18,2,15,10));
        //setting the background color, usign RGB code
        contentPane.setBackground(new Color(220,220,220));// gainsboro color

        contentPane.add(Box.createHorizontalGlue());    //The 'Box.createHorizontalGlue()' method creates a new invisible component that                                              
        contentPane.add(Box.createHorizontalGlue());    //can be used to add horizontal spacing between other components in the container.
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());

        JLabel staffNameLabel = new JLabel("Staff Name:");          //creating a new Label with name "staffNameLabel"
        staffNameLabel.setFont(new Font("Bell MT",Font.BOLD,15));   // setting the Font-name,weight and size of the label
        staffNameLabel.setForeground(new Color(0,0,128));           // setting the Font color of the label to navy
        staffNameLabel.setHorizontalAlignment(JLabel.CENTER);       // setting the horizontal alignment of the label to center
        staffNameTextF = new JTextField(16);                       // creating a new Text Field with length of 16 characters
        // creating a line border with color around the Text-field with width of 1 pixel
        staffNameTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1)); 
        contentPane.add(staffNameLabel);                         // adding the Label to the Content Pane
        contentPane.add(staffNameTextF);                         // adding the TextField to the Content Pane

        JLabel vacancyNumberLabel = new JLabel("Vacancy Number:");
        vacancyNumberLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        vacancyNumberLabel.setForeground(new Color(0,0,128));
        vacancyNumberLabel.setHorizontalAlignment(JLabel.CENTER);
        vacancyNumberTextF = new JTextField(16);
        vacancyNumberTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(vacancyNumberLabel);
        contentPane.add(vacancyNumberTextF);  

        JLabel designationLabel = new JLabel("Designation: ");
        designationLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        designationLabel.setForeground(new Color(0,0,128));
        designationLabel.setHorizontalAlignment(JLabel.CENTER);
        designationTextF = new JTextField(16);
        designationTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(designationLabel);
        contentPane.add(designationTextF);

        JLabel jobTypeLabel = new JLabel("Job type: ");
        jobTypeLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        jobTypeLabel.setForeground(new Color(0,0,128));
        jobTypeLabel.setHorizontalAlignment(JLabel.CENTER);
        jobTypeTextF = new JTextField(16);
        jobTypeTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(jobTypeLabel);
        contentPane.add(jobTypeTextF);

        JLabel joiningDateLabel = new JLabel("Join date: ");
        joiningDateLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        joiningDateLabel.setForeground(new Color(0,0,128));
        joiningDateLabel.setHorizontalAlignment(JLabel.CENTER);
        joiningDateTextF = new JTextField(16);
        joiningDateTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(joiningDateLabel);
        contentPane.add(joiningDateTextF);

        JLabel qualificationLabel = new JLabel("Qualification: ");
        qualificationLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        qualificationLabel.setForeground(new Color(0,0,128));
        qualificationLabel.setHorizontalAlignment(JLabel.CENTER);
        qualificationTextF = new JTextField(16);
        qualificationTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(qualificationLabel);
        contentPane.add(qualificationTextF);

        JLabel appointedByLabel = new JLabel("Appointed by: ");
        appointedByLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        appointedByLabel.setForeground(new Color(0,0,128));
        appointedByLabel.setHorizontalAlignment(JLabel.CENTER);
        appointedByTextF = new JTextField(16);
        appointedByTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(appointedByLabel);
        contentPane.add(appointedByTextF);

        joinedCheckBox = new JCheckBox();
        joinedCheckBox.setText("joined");
        joinedCheckBox.setHorizontalAlignment(JCheckBox.CENTER);
        joinedCheckBox.setBackground(new Color(220,220,220));
        joinedCheckBox.setFont(new Font("Bell MT",Font.BOLD,15));
        joinedCheckBox.setForeground(new Color(0,0,128));
        joinedCheckBox.setFocusable(false);  // sets the 'focusable' property of the button to 'false'. 
        contentPane.add(joinedCheckBox);     //This means that the button will not be able to receive focus when the user interacts with it.

        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue()); 
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());

        JLabel salaryLabel = new JLabel("Salary: ");
        salaryLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        salaryLabel.setForeground(new Color(0,0,128));
        salaryLabel.setHorizontalAlignment(JLabel.CENTER);
        salaryTextF = new JTextField(16);
        salaryTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(salaryLabel);
        contentPane.add(salaryTextF);

        JLabel weeklyFractionalHoursLabel = new JLabel("Weekly hours: ");
        weeklyFractionalHoursLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        weeklyFractionalHoursLabel.setForeground(new Color(0,0,128));
        weeklyFractionalHoursLabel.setHorizontalAlignment(JLabel.CENTER);
        weeklyFractionalHoursTextF = new JTextField(16);
        weeklyFractionalHoursTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(weeklyFractionalHoursLabel);
        contentPane.add(weeklyFractionalHoursTextF);

        JLabel addFullTimeLabel = new JLabel("Add Full Time:");
        addFullTimeLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        addFullTimeLabel.setForeground(new Color(0,0,128));
        addFullTimeLabel.setHorizontalAlignment(JLabel.CENTER);
        addFullTimeButton = new JButton("full time");
        addFullTimeButton.setFont(new Font("Bell MT",Font.BOLD,15));
        addFullTimeButton.setForeground(new Color(255,255,255)); // white color
        addFullTimeButton.setBackground(new Color(95,158,160)); // cadet blue color
        addFullTimeButton.setFocusable(false);
        contentPane.add(addFullTimeLabel);
        contentPane.add(addFullTimeButton);
        //This allows the program to respond to the user clicking the button by calling the appropriate method in the program code.
        addFullTimeButton.addActionListener(this); 

        JLabel addSalaryLabel = new JLabel("Add New Salary:");
        addSalaryLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        addSalaryLabel.setForeground(new Color(0,0,128));
        addSalaryLabel.setHorizontalAlignment(JLabel.CENTER);
        setSalaryButton = new JButton("salary");
        setSalaryButton.setFont(new Font("Bell MT",Font.BOLD,15));
        setSalaryButton.setForeground(new Color(255,255,255));
        setSalaryButton.setBackground(new Color(95,158,160));
        setSalaryButton.setFocusable(false); 
        contentPane.add(addSalaryLabel);
        contentPane.add(setSalaryButton);
        setSalaryButton.addActionListener(this); 

        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());

        JLabel workingHoursLabel = new JLabel("Hours per day: ");
        workingHoursLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        workingHoursLabel.setForeground(new Color(0,0,128));
        workingHoursLabel.setHorizontalAlignment(JLabel.CENTER);
        workingHoursTextF = new JTextField(16);
        workingHoursTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(workingHoursLabel);
        contentPane.add(workingHoursTextF);

        JLabel wagesPerHourLabel = new JLabel("Pay per hour: ");
        wagesPerHourLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        wagesPerHourLabel.setForeground(new Color(0,0,128));
        wagesPerHourLabel.setHorizontalAlignment(JLabel.CENTER);
        wagesPerHourTextF = new JTextField(16);
        wagesPerHourTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(wagesPerHourLabel);
        contentPane.add(wagesPerHourTextF);

        JLabel shiftLabel = new JLabel("Shift(m/d/e): ");
        shiftLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        shiftLabel.setForeground(new Color(0,0,128));
        shiftLabel.setHorizontalAlignment(JLabel.CENTER);
        shiftTextF = new JTextField(16);
        shiftTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(shiftLabel);
        contentPane.add(shiftTextF);

        JLabel daysPerWeekLabel = new JLabel("Days per week: ");
        daysPerWeekLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        daysPerWeekLabel.setForeground(new Color(0,0,128));
        daysPerWeekLabel.setHorizontalAlignment(JLabel.CENTER);
        daysPerWeekTextF = new JTextField(16);
        daysPerWeekTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(daysPerWeekLabel);
        contentPane.add(daysPerWeekTextF);

        JLabel addPartTimeLabel = new JLabel("Add Part Time:");
        addPartTimeLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        addPartTimeLabel.setForeground(new Color(0,0,128));
        addPartTimeLabel.setHorizontalAlignment(JLabel.CENTER);
        addPartTimeButton = new JButton("part time");
        addPartTimeButton.setFont(new Font("Bell MT",Font.BOLD,15));
        addPartTimeButton.setForeground(new Color(255,255,255));
        addPartTimeButton.setBackground(new Color(95,158,160));
        addPartTimeButton.setFocusable(false);
        contentPane.add(addPartTimeLabel);
        contentPane.add(addPartTimeButton);
        //This allows the program to respond to the user clicking the button by calling the appropriate method in the program code.
        addPartTimeButton.addActionListener(this); 

        JLabel addShiftLabel = new JLabel("Add New Shift:");
        addShiftLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        addShiftLabel.setForeground(new Color(0,0,128));
        addShiftLabel.setHorizontalAlignment(JLabel.CENTER);
        setWorkingShiftButton = new JButton("shift");
        setWorkingShiftButton.setFont(new Font("Bell MT",Font.BOLD,15));
        setWorkingShiftButton.setForeground(new Color(255,255,255));
        setWorkingShiftButton.setBackground(new Color(95,158,160));
        setWorkingShiftButton.setFocusable(false);
        contentPane.add(addShiftLabel);
        contentPane.add(setWorkingShiftButton);
        setWorkingShiftButton.addActionListener(this);

        JLabel terminatedLabel = new JLabel("Terminate Staff: ");
        terminatedLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        terminatedLabel.setForeground(new Color(0,0,128));
        terminatedLabel.setHorizontalAlignment(JLabel.CENTER);
        terminateButton = new JButton("terminate");
        terminateButton.setFont(new Font("Bell MT",Font.BOLD,15));
        terminateButton.setForeground(new Color(255,255,255));
        terminateButton.setBackground(new Color(95,158,160));
        terminateButton.setFocusable(false);
        contentPane.add(terminatedLabel);
        contentPane.add(terminateButton);
        terminateButton.addActionListener(this); 

        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());
        contentPane.add(Box.createHorizontalGlue());

        JLabel displayNumberLabel = new JLabel("Display number: ");
        displayNumberLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        displayNumberLabel.setForeground(new Color(0,0,128));
        displayNumberLabel.setHorizontalAlignment(JLabel.CENTER);
        displayNumberTextF = new JTextField(16);
        displayNumberTextF.setBorder(BorderFactory.createLineBorder(new Color(0,0,128),1));
        contentPane.add(displayNumberLabel);
        contentPane.add(displayNumberTextF);

        displayNumberButton = new JButton("display");
        displayNumberButton.setFont(new Font("Bell MT",Font.BOLD,15));
        displayNumberButton.setForeground(new Color(255,255,255));
        displayNumberButton.setBackground(new Color(95,158,160));
        displayNumberButton.setFocusable(false);
        contentPane.add(displayNumberButton);
        displayNumberButton.addActionListener(this); 

        contentPane.add(Box.createHorizontalGlue());

        JLabel clearLabel = new JLabel("Clear:");
        clearLabel.setFont(new Font("Bell MT",Font.BOLD,15));
        clearLabel.setForeground(new Color(0,0,128));
        clearLabel.setHorizontalAlignment(JLabel.CENTER);
        contentPane.add(clearLabel);

        clearButton = new JButton("clear");
        clearButton.setFont(new Font("Bell MT",Font.BOLD,15));
        clearButton.setForeground(new Color(255,255,255));
        clearButton.setBackground(new Color(95,158,160));
        clearButton.setFocusable(false);
        contentPane.add(clearButton);
        clearButton.addActionListener(this);

        frame.pack(); //this ensures that all of the components are arranged and sized correctly
        frame.setSize(730,670); // setting the size of the frame
        frame.setLayout(null); // setting the layout of the frame to null. By default has a "BorderLayout"
        frame.setResizable(false); // disable the ability to resize the window
        frame.setVisible(true); // setting the frame to visible, otherwise its contents are not displayed on the screen
    }

    /**
     * The main method allows the program to be run without BlueJ.
     */ 
    public static void main(String[] args)
    {
        RecruitmentSystem system = new RecruitmentSystem();
    }

    /**
     * The actionPerformed method is a method that handles user events in a graphical user interface (GUI) application. 
     * The method receives an ActionEvent object representing a user action, and based on the action command, 
     * it calls different methods to handle the event.
     */
    public void actionPerformed(ActionEvent event)
    {
        String command = event.getActionCommand();
        if (command.equals("full time")) {
            addFullTime();
        }

        if (command.equals("salary")) {
            addNewSalary();
        }

        if (command.equals("part time")) {
            addPartTime();
        }

        if (command.equals("shift")) {
            addNewShift();
        }

        if (command.equals("terminate")) {
            terminate();
        }

        if (command.equals("display")) {
            displayInfo();
        }

        if (command.equals("clear")) {
            clear();
        }
    }

    /**
     * This method creates a new "FullTimeStaffHire" object and adds it to the list of "StaffHire" objects.
     * The new object takes as a parameter all the new created methods related to the attributes in the FullTimeStaffHire class 
     * in a particular order.This method is checking the joined status if it`s true, if the status is false a message is showed to the user.
     * If the joined status is true but the weekly hours are less than 30, the method returns without adding the staff member to the staff list
     * and a suitable message is showed to the user. Then the method checks if any of the required information(such as the staff member's name or job type)
     * is missing, if so the method displays a message and returns without adding the staff member to the list.
     * Finally, if the status is true,the hours are more or equal to 30 and all the required information is there, the method 
     * displays a message box using the "JOptionPane.showMessageDialog" method to inform the user that a new full-time staff has been created.
     */
    public void addFullTime()
    {
        StaffHire newFullTimeStaff = new FullTimeStaffHire(getVacNumber(),getDesignation(),getJobType(),getName(), getJoiningDate(), 
                getQualification(), getAppointedBy(),getJoinedStatus(), getStaffSalary(), getWeeklyFractionalHours());

        if(getJoinedStatus() == true)
        {
            FullTimeStaffHire hours = (FullTimeStaffHire) newFullTimeStaff;
            if (getWeeklyFractionalHours() <= 29) {
                hours.setWeeklyHours(getWeeklyFractionalHours());
                JOptionPane.showMessageDialog(frame,"The minimum hours for this position is 30!");
                return;
            }
            if(getDesignation().isEmpty() || getJobType().isEmpty() || getName().isEmpty() || getJoiningDate().isEmpty() ||
            getQualification().isEmpty() || getAppointedBy().isEmpty())
            {
                JOptionPane.showMessageDialog(frame,"Please fill the missing information!");
                return;
            }
            staff.add(newFullTimeStaff);
            JOptionPane.showMessageDialog(frame,"Full time staff created!");
        }
        else{
            JOptionPane.showMessageDialog(frame,"The staff member hasn`t joined yet!");
        }
    }

    /**
     * This method creates a new "PartTimeStaffHire" object and adds it to the list of "StaffHire" objects.
     * The new object takes as a parameter all the new created methods related to the attributes in the PartTimeStaffHire class 
     * in a particular order. This method is checking the joined status if it`s true, if the status is false a message is showed to the user.
     * If the joined status is true but the hours per day are more than 10, the method returns without adding the staff member to the staff list
     * and a suitable message is showed to the user. Then the method checks if any of the required information(such as the staff member's name or job type)
     * is missing, and if so the method displays a message and returns without adding the staff member to the list. 
     * Finally, if the status is true,the hours are less or equal to 10 and all the information is added, the method displays a message box using 
     * the "JOptionPane.showMessageDialog" method to inform the user that a new part-time staff has been created.
     */
    public void addPartTime()
    {
        StaffHire newPartTimeStaff = new PartTimeStaffHire(getVacNumber(),getDesignation(),getJobType(),getName(), getJoiningDate(), 
                getQualification(), getAppointedBy(),getJoinedStatus(), getHoursPerDay(), getWagesPerHour(), getShift(), getDaysPerWeek());

        if(getJoinedStatus() == true)
        {
            PartTimeStaffHire dayHours = (PartTimeStaffHire) newPartTimeStaff;
            if (getHoursPerDay() > 10) {
                dayHours.setWorkingHours(getHoursPerDay());
                JOptionPane.showMessageDialog(frame,"The maximum hours per day is 10!");
                return;
            }
            if(getDesignation().isEmpty() || getJobType().isEmpty() || getName().isEmpty() || getJoiningDate().isEmpty() ||
            getQualification().isEmpty() || getAppointedBy().isEmpty() || getShift().isEmpty())
            {
                JOptionPane.showMessageDialog(frame,"Please fill the missing information!");
                return;
            }
            staff.add(newPartTimeStaff);
            JOptionPane.showMessageDialog(frame,"Part time staff created!");
        }else{
            JOptionPane.showMessageDialog(frame,"The staff member hasn`t joined yet!");
        }
    }

    /**
     *This method shows how to set a new salary for a full-time staff in a Java program. 
     *The method first retrieves the staff object from the list, checks its type to ensure that it is an instance of FullTimeStaffHire, checks
     *if the joined status is true and then sets the new salary by calling the setSalary method from the FullTimeStaffHire class. 
     *The method also displays an appropriate message box to inform the user whether the operation was successful or not.
     */
    public void addNewSalary()
    {
        StaffHire fStaff = staff.get(getDisplayNum());
        if(fStaff instanceof FullTimeStaffHire){
            if(getJoinedStatus() == true){
                FullTimeStaffHire fullStaff = (FullTimeStaffHire) fStaff;
                fullStaff.setSalary(getJoinedStatus(),getStaffSalary());
                JOptionPane.showMessageDialog(frame,"The new salary is added!");
            }else{
                JOptionPane.showMessageDialog(frame,"There is no staff to set the salary");
            }
        } else{
            JOptionPane.showMessageDialog(frame,"Error!Try again!");
        }
    }

    /**
     *This method shows how to set a new shift for a part-time staff member in a Java program. 
     *The method first retrieves the staff object from the list, checks its type to ensure that it is an instance of PartTimeStaffHire, checks
     *if the joined status is true and then sets the new shift by calling the setChangeShift method from the PartTimeStaffHire class. 
     *The method also displays an appropriate message box to inform the user whether the operation was successful or not.
     */
    public void addNewShift()
    {
        StaffHire nStaff = staff.get(getDisplayNum());
        if(nStaff instanceof PartTimeStaffHire){
            if(getJoinedStatus() == true){
                PartTimeStaffHire shiftPart = (PartTimeStaffHire) nStaff; 
                shiftPart.setChangeShift(getJoinedStatus(),getShift());
                JOptionPane.showMessageDialog(frame,"The new shift is added!");
            } else{ 
                JOptionPane.showMessageDialog(frame,"There is no staff to set the new shift");
            }
        } else{
            JOptionPane.showMessageDialog(frame,"Error!Try again!");
        }
    }

    /** 
     *This method shows how to terminate a part-time staff member from the list of staff in a Java program. 
     *The method first retrieves the staff object from the list, checks its type to ensure that it is an instance of PartTimeStaffHire, 
     *and then sets the terminate field to true. The method also displays an appropriate message box to inform the user whether 
     *the operation was successful or not.
     */
    public void terminate()
    {
        StaffHire Staff = staff.get(getDisplayNum());

        if(Staff instanceof PartTimeStaffHire){
            PartTimeStaffHire partStaff = (PartTimeStaffHire) Staff;
            partStaff.isTerminate(true);
            JOptionPane.showMessageDialog(frame,"The part time staff member is now terminated!");
        } else{
            JOptionPane.showMessageDialog(frame,"The index " + getDisplayNum() + " is not a part of the Part-time Staff");
        }
    }

    /**
     * This method retrieves the text from the staffNameTextF text field, which is where the user entered their name. 
     * It then returns the text as a string using the getText method.
     */
    public String getName()
    {
        return staffNameTextF.getText();
    }

    /**
     * This method retrieves the text from the vacancyNumberTextF text field, which is where the user entered the vacancy number.
     * But by default in GUI all the information is entered as a string. To convert it into an integer we use the Integer.parseInt method.
     * If the text cannot be parsed into an integer, we use the "try..catch" statement which is checking for errors while the code is being executed.
     */
    public int getVacNumber()
    {
        int getVacNumber = 0;
        try{
            getVacNumber = Integer.parseInt(vacancyNumberTextF.getText());
        }catch(NumberFormatException exception){
            JOptionPane.showMessageDialog(frame, "Please enter a vacancy number!");
        }
        return getVacNumber;
    }

    /**
     * This method retrieves the text from the designationTextF text field, which is where the user entered the designation. 
     * It then returns the text as a string using the getText method.
     */
    public String getDesignation()
    {
        return designationTextF.getText();
    }

    /**
     * This method retrieves the text from the jobTypeTextF text field, which is where the user entered the job type. 
     * It then returns the text as a string using the getText method.
     */
    public String getJobType()
    {
        return jobTypeTextF.getText();
    }

    /**
     * This method retrieves the text from the joiningDateTextF text field, which is where the user entered the joining date. 
     * It then returns the text as a string using the getText method.
     */
    public String getJoiningDate()
    {
        return joiningDateTextF.getText();
    }

    /**
     * This method retrieves the text from the qualificationTextF text field, which is where the user entered the qualification. 
     * It then returns the text as a string using the getText method.
     */
    public String getQualification()
    {
        return qualificationTextF.getText();
    }

    /**
     * This method retrieves the text from the appointedByTextF text field, which is where the user entered the appointed by-name. 
     * It then returns the text as a string using the getText method.
     */
    public String getAppointedBy()
    {
        return appointedByTextF.getText();
    }

    /**
     * This method retrieves the text from the getStaffSalaryTextF text field, which is where the user entered the salary.
     * But by default in GUI all the information is entered as a string. To convert it into double we use the Double.parseDouble method.
     * If the text cannot be parsed into an integer, we use the "try..catch" statement which is checking for errors while the code is being executed.
     */
    public double getStaffSalary()
    {
        double getStaffSalary = 0.0;
        try{
            getStaffSalary = Double.parseDouble(salaryTextF.getText());
        }catch(NumberFormatException exception){
            JOptionPane.showMessageDialog(frame, "Please enter a salary!");
        }
        return getStaffSalary;
    }

    /**
     * This method retrieves the text from the weeklyFractionalHoursTextF text field, which is where the user entered the weekly hours.
     * But by default in GUI all the information is entered as a string. To convert it into an integer we use the Integer.parseInt method.
     * If the text cannot be parsed into an integer, we use the "try..catch" statement which is checking for errors while the code is being executed.
     */
    public int getWeeklyFractionalHours()
    {
        int weeklyHours = 0;
        try{
            weeklyHours = Integer.parseInt(weeklyFractionalHoursTextF.getText());
        }catch(NumberFormatException exception){
            JOptionPane.showMessageDialog(frame, "Please enter the weekly hours!");
        }
        return weeklyHours;
    }

    /**
     * This method returns a boolean value indicating whether the staff member has joined or not.
     * To achieve this we are using the isSelected method.
     */
    public boolean getJoinedStatus()
    {
        boolean joined = joinedCheckBox.isSelected();
        return joined;
    }

    /**
     * This method retrieves the text from the workingHoursTextF text field, which is where the user entered the working hours.
     * But by default in GUI all the information is entered as a string. To convert it into an integer we use the Integer.parseInt method.
     * If the text cannot be parsed into an integer, we use the "try..catch" statement which is checking for errors while the code is being executed.
     */
    public int getHoursPerDay()
    {
        int getHoursPerDay = 0;
        try{
            getHoursPerDay = Integer.parseInt(workingHoursTextF.getText());
        }catch(NumberFormatException exception){
            JOptionPane.showMessageDialog(frame, "Please enter the hours per day!");
        }
        return getHoursPerDay;
    }

    /**
     * This method retrieves the text from the wagesPerHourTextF text field, which is where the user entered the wages per hour.
     * But by default in GUI all the information is entered as a string. To convert it into double we use the Double.parseDouble method.
     * If the text cannot be parsed into an integer, we use the "try..catch" statement which is checking for errors while the code is being executed.
     */
    public double getWagesPerHour()
    {
        double getWagesPerHour = 0.0;
        try{
            getWagesPerHour = Double.parseDouble(wagesPerHourTextF.getText());
        }catch(NumberFormatException exception){
            JOptionPane.showMessageDialog(frame, "Please enter the wage per hour!");
        }
        return getWagesPerHour;
    }

    /**
     * This method retrieves the text from the shiftTextF text field, which is where the user entered the shift. 
     * It then returns the text as a string using the getText method.
     */
    public String getShift()
    {
        return shiftTextF.getText();
    }

    /**
     * This method retrieves the text from the daysPerWeekTextF text field, which is where the user entered the days per week.
     * But by default in GUI all the information is entered as a string. To convert it into an integer we use the Integer.parseInt method.
     * If the text cannot be parsed into an integer, we use the "try..catch" statement which is checking for errors while the code is being executed.
     */
    public int getDaysPerWeek()
    {
        int getDaysPerWeek = 0;
        try{
            getDaysPerWeek = Integer.parseInt(daysPerWeekTextF.getText());
        } catch(NumberFormatException exception) {
            JOptionPane.showMessageDialog(frame, "Please enter the days per week!");
        }
        return getDaysPerWeek;
    }

    /**
     * This method retrieves the text from the displayNumberTextF text field, which is where the user entered the display number 
     * to see the information about the staff. The indices of the array list are starting from 0, that is why we are setting the getDisplayNum to -1.
     * By default in GUI all the information is entered as a string. To convert it into an integer we use the "Integer.parseInt" method.
     * If the text cannot be parsed into an integer, we use the "try..catch" statement which is checking for errors while the code is being executed.
     * This method also checks if the displayNum is within the range of the staff list and reset the displayNum to -1. 
     * If not an error message is displayed.
     */
    public int getDisplayNum() {
        int displayNum = -1;
        try {
            displayNum = Integer.parseInt(displayNumberTextF.getText());
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid number!");
        }
        if (displayNum < 0 || displayNum >= staff.size()) {
            JOptionPane.showMessageDialog(frame, "This number is not part of the list. Please enter a valid number!");
            displayNum = -1;
        }
        return displayNum;
    }

    /**
     * This method displays information about a specific staff member from the list of "staff". 
     * The method retrieves the staff object from the list, calls its display method to output the 
     * staff member's information, and then separates the output from the next staff member with a horizontal line.
     */ 
    public void displayInfo()
    {
        StaffHire displayStaff = staff.get(getDisplayNum());
        displayStaff.display();
        System.out.println("___________________");
        System.out.println("\n");
    }

    /**
     * This method clears all the information provided in the textfields. 
     * And sets it to an empty string.
     */      
    public void clear()
    {
        vacancyNumberTextF.setText("");
        designationTextF.setText("");
        jobTypeTextF.setText("");
        staffNameTextF.setText("");
        joiningDateTextF.setText("");
        qualificationTextF.setText("");
        appointedByTextF.setText("");
        salaryTextF.setText("");
        weeklyFractionalHoursTextF.setText("");
        workingHoursTextF.setText("");
        wagesPerHourTextF.setText("");
        shiftTextF.setText("");
        daysPerWeekTextF.setText("");
        displayNumberTextF.setText("");
    }
}
