/**
 * The StaffHire class represents a program for hiring new people.
 * This class serves as a superclass and has two subclasses: FullTimeStaffHire and PartTimeStaffHire.
 * All the information that is stored in the StaffHire class can be retrieved.
 * The StaffHire class has eight attributes and all these attributes give us the information that we need
 * to hire a new person.
 *
 * @author Stela Kostadinova
 * @student ID: 22042714
 * @date 19/01/2023
 */
public class StaffHire
{   
    // instance variables
    private int vacancyNumber; // The number of the vacancy
    private String designation; // Role or position: manager, assistant, director, etc.
    private String jobType; // The job type can be either temporary or permanent contract
    private String staffName; // The name of the new staff
    private String joiningDate; // The date that the person will join
    private String qualification; // Skills, experience, education, etc.
    private String appointedBy; // The person to which a person is appointed
    private boolean joined; // It can be either true or false. It indicates if the person has joined the company or not.

    /**
     * Constructor of class StaffHire. This constructor creates a new object of the class StaffHire.
     */
    public StaffHire(int vacancyNumber, String designation, String jobType, String staffName, String joiningDate, String qualification, String appointedBy,
    boolean joined)
    {
        // initializing the instance variables
        this.vacancyNumber = vacancyNumber; 
        this.designation = designation;
        this.jobType = jobType;
        this.staffName = staffName;
        this.joiningDate = joiningDate;
        this.qualification = qualification;
        this.appointedBy = appointedBy;
        this.joined = joined; 
    }

    /**
     * Enter a vacancy number for the person.
     * @param newVacancyNumber The new number to be entered.
     */
    public void setVacancyNumber(int newVacancyNumber)
    {
        vacancyNumber = newVacancyNumber;
    }

    /**
     * @return The vacancy number for this person.
     */
    public int getVacancyNumber()
    {
        return vacancyNumber;
    }

    /**
     * Enter the position for this person.
     * @param newDesignation The designation to be entered.
     */
    public void setDesignation(String newDesignation)
    {
        designation = newDesignation;
    }

    /**
     * @return The designation for this person.
     */
    public String getDesignation()
    {
        return designation;
    }

    /**
     * Enter the job type for this person.
     * @param newJobType The new jobType to be entered.
     */
    public void setJobType(String newJobType)
    {
        jobType = newJobType;
    }

    /**
     * @return The job type for this person.
     */
    public String getJobType()
    {
        return jobType;
    }

    /**
     * Enter the full name for this person.
     * @param fullName The full name to be entered.
     */
    public void setStaffName(String fullName)
    {
        staffName = fullName;
    }

    /**
     * @return The staff name.
     */
    public String getStaffName()
    {
        return staffName;
    }

    /**
     * Enter the joining date for this person.
     * @param newJoiningDate The joining date to be entered.
     */
    public void setJoiningDate(String newJoiningDate)
    {
        joiningDate = newJoiningDate;
    }

    /**
     * @return The joining date.
     */
    public String getJoiningDate()
    {
        return joiningDate;
    }

    /**
     * Enter the qualification/degree of this person.
     * @param newQualification The qualification to be entered.
     */
    public void setQualification(String newQualification)
    {
        qualification = newQualification;
    }

    /**
     * @return The qualification.
     */
    public String getQualification()
    {
        return qualification;
    }

    /**
     * Enter the name for this person.
     * @param newAppointedBy The appointed by to be entered.
     */
    public void setAppointedBy(String newAppointedBy)
    {
        appointedBy = newAppointedBy;
    }

    /**
     * @return The appointed by.
     */
    public String getAppointedBy()
    {
        return appointedBy;
    }

    /**
     * Here we are changing the status join to true if the person has joined the company, or false if it doesn`t.
     * @param newJoined Joined to be entered.
     */
    public void setJoined(boolean newJoined) 
    {
        joined = newJoined;
    }

    /**
     * @return The status joined. Either true or false.
     */
    public boolean getJoined() 
    {
        return joined;
    }

    /**
     * Print all the details that has been entered to the text terminal in the order presented.
     */
    public void display() 
    {
        System.out.println("Vacancy number: " + vacancyNumber);
        System.out.println("Designation/position: " + designation);
        System.out.println("Job type: " + jobType);
        System.out.println("Full name: " + staffName);
        System.out.println("Joining date: " + joiningDate);
        System.out.println("Qualification/degree: " + qualification);
        System.out.println("Appointed by: " + appointedBy);
        System.out.println("Status joined:  " + joined);
    }

}
